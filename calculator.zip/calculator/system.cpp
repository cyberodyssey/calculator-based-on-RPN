#include<windows.h>
#include<stdio.h>
void help_4_arithmetic_operations(void);
void RPN(void);
void cls()
{
	Sleep(500);
	system("cls");
}
void begin()
{
	printf("program is beginning\n");
	cls();
	int function_choose=127;
	while(function_choose)
	{
		printf("----------------------------------------------------------------------------------------------\n");
		printf("choose the function\n");
		printf("----------------------------------------------------------------------------------------------\n");
		printf("1.4-arithmetic-operations\n");
		printf("2.reverse matrix\n");
		printf("3.solving univariate equation\\equation with just one var\n");
		printf("4.function waited to be developed\n");
		printf("5.helps\n");
		printf("0.exit\n");
		printf("----------------------------------------------------------------------------------------------\n");
		scanf("%d",&function_choose);
		//function array will be deployed in future
		/*
			keep alive while having chosen a function
			exit by return (int)0 through function
		*/
		switch(function_choose)
		{
			case 0:
			{
				cls();
				printf("thanks for using\n");
				break;
			}
			case 1:
			{
				RPN();	
				break;
			}
			case 2:
			{
				break;
			}
			case 3:
			{
				break;
			}
			case 4:
			{
				break;
			}
			case 5:
			{
				int num_of_function=1;
				while(num_of_function)
				{
					printf("*enter the number of function to get help\n");
					printf("*press 0 to exit\n");
					scanf("%d",&num_of_function);
					if(num_of_function==0)
						break;
					switch(num_of_function)
					{
						case 1:
						{
							help_4_arithmetic_operations();
							break;
						}
						case 2:
						{
							break;
						}
						case 3:
						{
							break;
						}
						break;
					}
				}
				system("cls");
				break;
			}
			break;
		}
		system("cls");
	}
}
