#include<stdio.h>
void help_4_arithmetic_operations(void)
{
	printf("calculate 4-arithmetic-operations based on RPN\n");
	printf("RPN is a type of formula which is different from infix and its full name is reverse polish notation\n");
	printf("infix is a normal type of formula ,for example,1+(2+3)*4 is a typical infix\n");
	printf("RPN is a significant type of formula, it makes great sense to calculate formula on computer\n");
	printf("the program provides an example\n");
	printf("infix is 1+(2+3)*4\n");
	printf("RPN is 123+4*+\n");
	printf("in this program, this function is based on stack operations\n");
}
