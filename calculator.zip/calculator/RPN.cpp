#include<stdio.h>
#include<string.h>
//check if valid 
int priority(char ch);
void RPN(void)
{
	getchar();
	while(1)
	{
		printf("press an infix\n");
		char infix[100];
		char rpn[100];
		char o_stack[100];
		char op_stack[100];
		double data[100];
		
		memset(data,0,sizeof(data));
		scanf("%[^\n]s",infix);
		getchar();
		int f_top,o_top;
		f_top=0,o_top=0;
		int d_top,op_top;
		d_top=0,op_top=0;
		
		int i;
		for(i=0;infix[i]!='\0';i++)
		{
			if(infix[i]<='9'&&infix[i]>='0')
			{
				rpn[f_top]=infix[i];
				f_top++;
			}
			else if(infix[i]=='+'||infix[i]=='-'||infix[i]=='*'||infix[i]=='/')
			{
				if(o_top==0)
				{
					o_stack[o_top]=infix[i];
					o_top++;
				}
				else
				{
					if(priority(infix[i])>priority(o_stack[o_top-1]))
					{
						o_stack[o_top]=infix[i];
						o_top++;
					}
					else
					{
						while(priority(infix[i])<=priority(o_stack[o_top-1])&&o_top!=0)
						{
							rpn[f_top]=o_stack[o_top-1];
							o_top--;
							f_top++;
						}
						if(o_top==0)
						{
							o_stack[o_top]=infix[i];
							o_top++;
						}
					}
				}
			}
			else if(infix[i]=='(')
			{
				o_stack[o_top]='(';
				o_top++;
			}
			else if(infix[i]==')')
			{
				while(o_stack[o_top-1]!='(')
				{
					char temp;
					temp=o_stack[o_top-1];
					o_stack[o_top-1]='\0';
					o_top--;
					rpn[f_top]=temp;
					f_top++;
				}
				o_stack[o_top-1]='\0';
				o_top--;
			}
		}
		while(o_top!=0)
		{
			char temp_2;
			temp_2=o_stack[o_top-1];
			o_stack[o_top-1]='\0';
			o_top--;
			rpn[f_top]=temp_2;
			f_top++;
		}
		printf("Infix is %s\nRPN is:%s\n",infix,rpn);
		
		int j;
		for(j=0;rpn[j]!='\0';j++)
		{
			if(rpn[j]>='0'&&rpn[j]<='9')
			{
				data[d_top]=(double)(rpn[j]-'0');
				d_top++;
			}
			else if(rpn[j]=='+'||rpn[j]=='-'||rpn[j]=='*'||rpn[j]=='/')
			{
				op_stack[op_top]=rpn[j];
				op_top++;
			}
			
			if(d_top>1&&op_top>0)
			{
				char operation;
				double value_cal;
				operation=op_stack[op_top-1];
				if(operation=='+')
				{
					value_cal=data[d_top-1]+data[d_top-2];
					data[d_top-1]=0;
					data[d_top-2]=value_cal;
				}
				if(operation=='-')
				{
					value_cal=data[d_top-2]-data[d_top-1];
					data[d_top-1]=0;
					data[d_top-2]=value_cal;
				}
				if(operation=='*')
				{
					value_cal=data[d_top-1]*data[d_top-2];
					data[d_top-1]=0;
					data[d_top-2]=value_cal;
				}
				if(operation=='/')
				{
					value_cal=data[d_top-2]/data[d_top-1];
					data[d_top-1]=0;
					data[d_top-2]=value_cal;
				}
				op_stack[op_top-1]='\0';
				op_top--;
				d_top--;
			}
		}
		printf("result is %.2lf\n",data[0]);
	}
}

int priority(char ch)
{
	int pri=0;
	if(ch=='+'||ch=='-')
	{
		pri=1;
	}
	else if(ch=='*'||ch=='/')
	{
		pri=2;
	}
	return pri;
}
