#include<stdio.h>
#include<iostream>
using namespace std;
void begin(void);

int main(void)
{
	begin();
	
	return 0;
}
